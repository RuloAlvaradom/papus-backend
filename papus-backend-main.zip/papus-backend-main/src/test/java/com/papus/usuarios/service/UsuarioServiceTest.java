package com.papus.usuarios.service;

import com.papus.usuarios.model.Usuario;
import com.papus.usuarios.repository.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UsuarioServiceTest {

    private UsuarioRepository usuarioRepository;
    private UsuarioService usuarioService;

    @BeforeEach
    public void setUp() {
        usuarioRepository = mock(UsuarioRepository.class);
        usuarioService = new UsuarioService();
        usuarioService.setUsuarioRepository(usuarioRepository);
    }

    //guardar usuario
    @Test
    public void testGuardarUsuario() {

        System.out.println("Ejecutando testGuardarUsuario");
        
        Usuario usuario = new Usuario();
        usuario.setNombre("Raúl");
        usuario.setApellido("Alvarado");
        usuario.setCorreo("raul@example.com");
        usuario.setContrasena("123456");
        usuario.setRol("ADMIN");

        when(usuarioRepository.save(usuario)).thenReturn(usuario);

        Usuario guardado = usuarioService.save(usuario);

        assertNotNull(guardado);
        assertEquals("Raúl", guardado.getNombre());
        verify(usuarioRepository, times(1)).save(usuario);
    }

    //buscar por rol
    @Test
    public void testBuscarPorRol() {

        System.out.println("Ejecutando testBuscarPorRol");

        Usuario u1 = new Usuario();
        u1.setRol("ADMIN");

        Usuario u2 = new Usuario();
        u2.setRol("ADMIN");

        List<Usuario> usuarios = Arrays.asList(u1, u2);

        when(usuarioRepository.findByRol("ADMIN")).thenReturn(usuarios);

        List<Usuario> resultado = usuarioService.buscarPorRol("ADMIN");

        assertEquals(2, resultado.size());
        verify(usuarioRepository, times(1)).findByRol("ADMIN");
    }
}

