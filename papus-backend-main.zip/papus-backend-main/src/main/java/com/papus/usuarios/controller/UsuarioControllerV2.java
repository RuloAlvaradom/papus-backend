package com.papus.usuarios.controller;

import com.papus.usuarios.model.Usuario;
import com.papus.usuarios.service.UsuarioService;
import com.papus.usuarios.assembler.UsuarioModelAssembler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v2/usuarios")
public class UsuarioControllerV2 {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private UsuarioModelAssembler assembler;

    @GetMapping
    public CollectionModel<EntityModel<Usuario>> listar() {
        List<EntityModel<Usuario>> usuarios = usuarioService.findAll().stream()
            .map(assembler::toModel)
            .collect(Collectors.toList());

        return CollectionModel.of(usuarios,
            linkTo(methodOn(UsuarioControllerV2.class).listar()).withSelfRel());
    }

    @GetMapping("/{id}")
    public EntityModel<Usuario> obtenerPorId(@PathVariable Long id) {
        Usuario usuario = usuarioService.findById(id)
            .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        return assembler.toModel(usuario);
    }

    @GetMapping("/rol/{rol}")
    public CollectionModel<EntityModel<Usuario>> buscarPorRol(@PathVariable String rol) {
        List<EntityModel<Usuario>> usuarios = usuarioService.buscarPorRol(rol).stream()
            .map(assembler::toModel)
            .collect(Collectors.toList());

        return CollectionModel.of(usuarios,
            linkTo(methodOn(UsuarioControllerV2.class).buscarPorRol(rol)).withSelfRel(),
            linkTo(methodOn(UsuarioControllerV2.class).listar()).withRel("todos-usuarios"));
    }
}

