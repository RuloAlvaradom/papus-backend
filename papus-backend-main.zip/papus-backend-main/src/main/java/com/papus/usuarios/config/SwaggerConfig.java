package com.papus.usuarios.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.context.annotation.Configuration;

@Configuration
@OpenAPIDefinition(info = @Info(title = "API Usuarios", version = "1.0", description = "Documentación del Microservicio de Usuarios"))
public class SwaggerConfig {
    // Clase vacía si no hay personalización adicional
}
