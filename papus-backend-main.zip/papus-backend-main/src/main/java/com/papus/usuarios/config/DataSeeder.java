package com.papus.usuarios.config;

import com.papus.usuarios.model.Usuario;
import com.papus.usuarios.repository.UsuarioRepository;
import net.datafaker.Faker;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataSeeder {

    @Bean
    public CommandLineRunner cargarDatosIniciales(UsuarioRepository usuarioRepository) {
        return args -> {
            if (usuarioRepository.count() == 0) {
                Faker faker = new Faker();

                for (int i = 0; i < 5; i++) {
                    Usuario usuario = new Usuario();
                    usuario.setNombre(faker.name().firstName());
                    usuario.setApellido(faker.name().lastName());
                    usuario.setCorreo(faker.internet().emailAddress());
                    usuario.setContrasena("123456");
                    usuario.setRol(i % 2 == 0 ? "ADMIN" : "VENDEDOR");

                    usuarioRepository.save(usuario);
                }

                System.out.println("Se insertaron usuarios");
            }
        };
    }
}

