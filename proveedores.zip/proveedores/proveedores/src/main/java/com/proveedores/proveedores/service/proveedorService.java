package com.proveedores.proveedores.service;

import com.proveedores.proveedores.model.Proveedor;
import com.proveedores.proveedores.repository.proveedoresRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional //Asegura que las operaciones se ejecuten en una transaccion
public class proveedorService {

    @Autowired
    private proveedoresRepository proveedoresRepository;

    //Guardar o actualizar
    public Proveedor save(Proveedor proveedor) {
        return proveedoresRepository.save(proveedor);
    }

    //Listar todos
    public List<Proveedor> findAll() {
        return proveedoresRepository.findAll();
    }

    //buscar por ID
    public Optional<Proveedor> findById(Long id) {
        return proveedoresRepository.findById(id);
    }

    //Eliminar por ID
    public void deleteById(Long id) {
        proveedoresRepository.deleteById(id);
    }

}
