package com.proveedores.proveedores.repository;

import com.proveedores.proveedores.model.Proveedor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface proveedoresRepository extends JpaRepository<Proveedor, Long> {

}
