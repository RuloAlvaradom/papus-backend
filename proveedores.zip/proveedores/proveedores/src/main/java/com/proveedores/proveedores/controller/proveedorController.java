package com.proveedores.proveedores.controller;

import com.proveedores.proveedores.model.Proveedor;
import com.proveedores.proveedores.service.proveedorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/v1/proovedores")

public class proveedorController {

    @Autowired
    private proveedorService proveedoresService;

    // GET - listar todos
    @GetMapping
    public ResponseEntity<List<Proveedor>> listar() {
        return ResponseEntity.ok(proveedoresService.findAll());
    }

    // GET - buscar por ID
    @GetMapping("/{id}")
    public ResponseEntity<Proveedor> obtenerPorId(@PathVariable Long id) {
        return proveedoresService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // POST - crear
    @PostMapping
    public ResponseEntity<Proveedor> crear(@RequestBody Proveedor proveedor) {
        return ResponseEntity.ok(proveedoresService.save(proveedor));
    }

    // PUT - actualizar
    @PutMapping("/{id}")
    public ResponseEntity<Proveedor> actualizar(@PathVariable Long id, @RequestBody Proveedor proveedor) {
        return proveedoresService.findById(id).map(u -> {
            proveedor.setId_proovedor(id);
            return ResponseEntity.ok(proveedoresService.save(proveedor));
        }).orElse(ResponseEntity.notFound().build());
    }

    // DELETE - eliminar
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (proveedoresService.findById(id).isPresent()) {
            proveedoresService.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build(); 
        }
    }

}
