package com.proveedores.proveedores.model;

import java.time.LocalDate;

import jakarta.persistence.*; //Para conectar con MySQL
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.List;

@Entity // Marca esta clase como una entidad de base de datos
@Table(name = "proveedores") // El nombre de la tabla será "proovedores"
@Getter @Setter // Genera automáticamente getters y setters (Lombok)
@NoArgsConstructor // Genera un constructor vacío

public class Proveedor {
    @Id // Marca este campo como la clave primaria
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_proveedor;

    @Column(nullable = false) 
    private String nombre_proveedor;

    @Column(nullable = false)
    private String email_proveedor;

    @Column(nullable = false)
    private String apellido_proveedor;

    @Column(nullable = false, unique = true) 
    private String correo_proveedor;

    @Column(nullable = false)
    private Integer telefono_proveedor;

    @Column(nullable = false)
    private String estado_proveedor;

    @Column(nullable = false)
    private String rut_proveedor;

    private Double evaluacionDesempeno;

    /**
     * Fecha en la que se registró el proveedor en el sistema.
     * Este parámetro sirve para: auditoría y antigüedad.
     */

    @Column(nullable = false)
    private LocalDate fechaRegistro;

    /**
     * IDs de pedidos realizados al proveedor.
     * Este parámetro sirve para: consultar el historial de compras para análisis o auditoría.
     */

    @ElementCollection
    @CollectionTable(name = "proveedor_pedidos", joinColumns = @JoinColumn(name = "proveedor_id"))
    @Column(name = "pedido_id")
    private List<Long> pedidosRealizados;

    /**
     * Texto con reclamos, devoluciones, retrasos u otros eventos.
     * Este parámetro sirve para: tener trazabilidad de problemas con el proveedor.
     */

    @Column(length = 2000)
    private String incidencias;

    @Column(nullable = false)
    private String metodoEnvio;

    @Column(nullable = false)
    private Integer tiempoEntregaDias;

    // --- Getters y Setters ---

    public Long getId_proveedor() {
        return id_proveedor;
    }

    public void setId_proveedor(Long id) {
        this.id_proveedor = id;
    }

    public String getNombre_proveedor() {
        return nombre_proveedor;
    }

    public void setNombre_proveedor(String nombre) {
        this.nombre_proveedor = nombre_proveedor;
    }

    public String getRut_proveedor() {
        return rut_proveedor;
    }

    public void setRut_proveedor(String rut) {
        this.rut_proveedor = rut_proveedor;
    }

    public String getEmail_proveedor() {
        return email_proveedor;
    }

    public void setEmail_proveedor(String email) {
        this.email_proveedor = email_proveedor;
    }

    public Integer getTelefono_proveedor() {
        return telefono_proveedor;
    }

    public void setTelefono_proveedor(Integer telefono) {
        this.telefono_proveedor = telefono_proveedor;
    }

    public String getEstadoProveedor_proveedor() {
        return estado_proveedor;
    }

    public void setEstadoProveedor_proveedor(String estadoProveedor) {
        this.estado_proveedor = estadoProveedor;
    }

    public Double getEvaluacionDesempeno_proveedor() {
        return evaluacionDesempeno;
    }

    public void setEvaluacionDesempeno_proveedor(Double evaluacionDesempeno) {
        this.evaluacionDesempeno = evaluacionDesempeno;
    }

    public LocalDate getFechaRegistro_proveedor() {
        return fechaRegistro;
    }

    public void setFechaRegistro_proveedor(LocalDate fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public List<Long> getPedidosRealizados_proveedor() {
        return pedidosRealizados;
    }

    public void setPedidosRealizados_proveedor(List<Long> pedidosRealizados) {
        this.pedidosRealizados = pedidosRealizados;
    }

    public String getIncidencias_proveedor() {
        return incidencias;
    }

    public void setIncidencias_proveedor(String incidencias) {
        this.incidencias = incidencias;
    }
    
    public String getMetodoEnvio_proveedor() {
        return metodoEnvio;
    }
    
    public void setMetodoEnvio_proveedor(String metodoEnvio) {
        this.metodoEnvio = metodoEnvio;
    }
    
    public Integer getTiempoEntregaDias_proveedor() {
        return tiempoEntregaDias;
    }
    
    public void setTiempoEntregaDias_proveedor(Integer tiempoEntregaDias) {
        this.tiempoEntregaDias = tiempoEntregaDias;
    }
}




