package com.proveedores.proveedores.model;

import jakarta.persistence.*; //Para conectar con MySQL
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity // Marca esta clase como una entidad de base de datos
@Table(name = "proovedores") // El nombre de la tabla será "proovedores"
@Getter @Setter // Genera automáticamente getters y setters (Lombok)
@NoArgsConstructor // Genera un constructor vacío

public class Proveedor {
    @Id // Marca este campo como la clave primaria
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_proovedor;

    @Column(nullable = false) 
    private String nombre_proovedor;

    @Column(nullable = false)
    private String apellido_proovedor;

    @Column(nullable = false, unique = true) 
    private String correo;

    @Column(nullable = false)
    private Integer telefono_proovedor;
}
